# TODO: create test for news routes
